package com.google.android.gms.base;

/* renamed from: com.google.android.gms.base.R */
public final class C0541R {
}
