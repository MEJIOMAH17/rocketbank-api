package com.google.android.gms.internal;

public class zza extends zzs {
    public zza(zzj zzj) {
        super(zzj);
    }

    public String getMessage() {
        return super.getMessage();
    }
}
