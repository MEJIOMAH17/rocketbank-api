package com.google.android.gms.internal;

public abstract class zzaqa<T> {
    private final int zzAW;
    private final String zzAX;
    private final T zzAY;

    public static class zza extends zzaqa<Boolean> {
        public zza(int i, String str, Boolean bool) {
            super(i, str, bool);
        }

        public /* synthetic */ Object zza(zzaqd zzaqd) {
            return zzb(zzaqd);
        }

        public java.lang.Boolean zzb(com.google.android.gms.internal.zzaqd r4) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1556461159.run(Unknown Source)
*/
            /*
            r3 = this;
            r0 = r3.getKey();	 Catch:{ RemoteException -> 0x001b }
            r1 = r3.zzfr();	 Catch:{ RemoteException -> 0x001b }
            r1 = (java.lang.Boolean) r1;	 Catch:{ RemoteException -> 0x001b }
            r1 = r1.booleanValue();	 Catch:{ RemoteException -> 0x001b }
            r2 = r3.getSource();	 Catch:{ RemoteException -> 0x001b }
            r4 = r4.getBooleanFlagValue(r0, r1, r2);	 Catch:{ RemoteException -> 0x001b }
            r4 = java.lang.Boolean.valueOf(r4);	 Catch:{ RemoteException -> 0x001b }
            return r4;
        L_0x001b:
            r4 = r3.zzfr();
            r4 = (java.lang.Boolean) r4;
            return r4;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaqa.zza.zzb(com.google.android.gms.internal.zzaqd):java.lang.Boolean");
        }
    }

    public static class zzb extends zzaqa<Integer> {
        public zzb(int i, String str, Integer num) {
            super(i, str, num);
        }

        public /* synthetic */ Object zza(zzaqd zzaqd) {
            return zzc(zzaqd);
        }

        public java.lang.Integer zzc(com.google.android.gms.internal.zzaqd r4) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1556461159.run(Unknown Source)
*/
            /*
            r3 = this;
            r0 = r3.getKey();	 Catch:{ RemoteException -> 0x001b }
            r1 = r3.zzfr();	 Catch:{ RemoteException -> 0x001b }
            r1 = (java.lang.Integer) r1;	 Catch:{ RemoteException -> 0x001b }
            r1 = r1.intValue();	 Catch:{ RemoteException -> 0x001b }
            r2 = r3.getSource();	 Catch:{ RemoteException -> 0x001b }
            r4 = r4.getIntFlagValue(r0, r1, r2);	 Catch:{ RemoteException -> 0x001b }
            r4 = java.lang.Integer.valueOf(r4);	 Catch:{ RemoteException -> 0x001b }
            return r4;
        L_0x001b:
            r4 = r3.zzfr();
            r4 = (java.lang.Integer) r4;
            return r4;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaqa.zzb.zzc(com.google.android.gms.internal.zzaqd):java.lang.Integer");
        }
    }

    public static class zzc extends zzaqa<Long> {
        public zzc(int i, String str, Long l) {
            super(i, str, l);
        }

        public /* synthetic */ Object zza(zzaqd zzaqd) {
            return zzd(zzaqd);
        }

        public java.lang.Long zzd(com.google.android.gms.internal.zzaqd r5) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1556461159.run(Unknown Source)
*/
            /*
            r4 = this;
            r0 = r4.getKey();	 Catch:{ RemoteException -> 0x001b }
            r1 = r4.zzfr();	 Catch:{ RemoteException -> 0x001b }
            r1 = (java.lang.Long) r1;	 Catch:{ RemoteException -> 0x001b }
            r1 = r1.longValue();	 Catch:{ RemoteException -> 0x001b }
            r3 = r4.getSource();	 Catch:{ RemoteException -> 0x001b }
            r0 = r5.getLongFlagValue(r0, r1, r3);	 Catch:{ RemoteException -> 0x001b }
            r5 = java.lang.Long.valueOf(r0);	 Catch:{ RemoteException -> 0x001b }
            return r5;
        L_0x001b:
            r5 = r4.zzfr();
            r5 = (java.lang.Long) r5;
            return r5;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaqa.zzc.zzd(com.google.android.gms.internal.zzaqd):java.lang.Long");
        }
    }

    public static class zzd extends zzaqa<String> {
        public zzd(int i, String str, String str2) {
            super(i, str, str2);
        }

        public /* synthetic */ Object zza(zzaqd zzaqd) {
            return zze(zzaqd);
        }

        public java.lang.String zze(com.google.android.gms.internal.zzaqd r4) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1556461159.run(Unknown Source)
*/
            /*
            r3 = this;
            r0 = r3.getKey();	 Catch:{ RemoteException -> 0x0013 }
            r1 = r3.zzfr();	 Catch:{ RemoteException -> 0x0013 }
            r1 = (java.lang.String) r1;	 Catch:{ RemoteException -> 0x0013 }
            r2 = r3.getSource();	 Catch:{ RemoteException -> 0x0013 }
            r4 = r4.getStringFlagValue(r0, r1, r2);	 Catch:{ RemoteException -> 0x0013 }
            return r4;
        L_0x0013:
            r4 = r3.zzfr();
            r4 = (java.lang.String) r4;
            return r4;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaqa.zzd.zze(com.google.android.gms.internal.zzaqd):java.lang.String");
        }
    }

    private zzaqa(int i, String str, T t) {
        this.zzAW = i;
        this.zzAX = str;
        this.zzAY = t;
        zzaqe.zzDE().zza(this);
    }

    public static zza zzb(int i, String str, Boolean bool) {
        return new zza(i, str, bool);
    }

    public static zzb zzb(int i, String str, int i2) {
        return new zzb(i, str, Integer.valueOf(i2));
    }

    public static zzc zzb(int i, String str, long j) {
        return new zzc(i, str, Long.valueOf(j));
    }

    public static zzd zzc(int i, String str, String str2) {
        return new zzd(i, str, str2);
    }

    public T get() {
        return zzaqe.zzDF().zzb(this);
    }

    public String getKey() {
        return this.zzAX;
    }

    public int getSource() {
        return this.zzAW;
    }

    protected abstract T zza(zzaqd zzaqd);

    public T zzfr() {
        return this.zzAY;
    }
}
