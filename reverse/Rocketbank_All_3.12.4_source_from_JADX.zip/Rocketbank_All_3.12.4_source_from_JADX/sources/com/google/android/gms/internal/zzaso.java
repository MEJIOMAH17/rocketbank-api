package com.google.android.gms.internal;

import android.os.DeadObjectException;
import android.os.IInterface;

public interface zzaso<T extends IInterface> {
    void zzxC();

    T zzxD() throws DeadObjectException;
}
