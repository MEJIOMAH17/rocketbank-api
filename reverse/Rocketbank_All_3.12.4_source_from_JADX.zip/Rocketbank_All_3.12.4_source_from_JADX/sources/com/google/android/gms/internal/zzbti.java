package com.google.android.gms.internal;

import com.google.android.gms.tasks.Task;

public interface zzbti {
    Task<Object> zzaW(boolean z);
}
