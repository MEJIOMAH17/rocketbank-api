package rx;

public interface Producer {
    void request(long j);
}
