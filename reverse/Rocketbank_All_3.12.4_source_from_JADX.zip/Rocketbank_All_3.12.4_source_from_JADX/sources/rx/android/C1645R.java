package rx.android;

/* renamed from: rx.android.R */
public final class C1645R {
}
