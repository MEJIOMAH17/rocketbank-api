package rx.internal.util.unsafe;

/* compiled from: SpscUnboundedArrayQueue */
abstract class SpscUnboundedArrayQueueConsumerField<E> extends SpscUnboundedArrayQueueConsumerColdField<E> {
    protected long consumerIndex;

    SpscUnboundedArrayQueueConsumerField() {
    }
}
