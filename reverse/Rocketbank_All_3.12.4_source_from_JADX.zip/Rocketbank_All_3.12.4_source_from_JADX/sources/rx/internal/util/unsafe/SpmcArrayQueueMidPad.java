package rx.internal.util.unsafe;

/* compiled from: SpmcArrayQueue */
abstract class SpmcArrayQueueMidPad<E> extends SpmcArrayQueueConsumerField<E> {
    long p20;
    long p21;
    long p22;
    long p23;
    long p24;
    long p25;
    long p26;
    long p30;
    long p31;
    long p32;
    long p33;
    long p34;
    long p35;
    long p36;
    long p37;

    public SpmcArrayQueueMidPad(int i) {
        super(i);
    }
}
