package rx.functions;

public interface Action0 extends Action {
    void call();
}
